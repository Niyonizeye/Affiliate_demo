<?php

namespace App\Http\Livewire;

use Livewire\Component;

class PackageComponent extends Component
{
    public function render()
    {
        return view('livewire.package-component');
    }
}
