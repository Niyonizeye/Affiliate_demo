

<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <!-- start of banner -->
    <!-- Hero Section Begin -->


    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100 col-md-4">
                <form class="login100-form validate-form" method="POST" <?php echo e(route('login')); ?> >
                    <?php echo csrf_field(); ?>
                    <span class="login100-form-title p-b-26">
                        Login Form
                    </span>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4 text-red']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4 text-red']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                    


                    <?php $__currentLoopData = ['danger','warning','success','info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has('alert-'.$msg)): ?>
                    <p class="alert alert-<?php echo e($msg); ?>" ><?php echo e(Session::get('alert-'.$msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>

                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="wrap-input100 validate-input" data-validate = "Valid email is: a@b.c">
                        <input class="input100" name="email" type="email" name="email" :value="old('email')" required autofocus >
                        <span class="focus-input100" data-placeholder="Enter Email"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter password">
                        <span class="btn-show-pass">
                            <i class="zmdi zmdi-eye"></i>
                        </span>
                        <input class="input100" name="password" type="password" name="password" required autocomplete="current-password">
                        <span class="focus-input100" data-placeholder="Enter Password"></span>
                    </div>

                    <div class="container-login100-form-btn">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                                    <button class="login100-form-btn" id="logbutton">
                                       Login
                                      <div class="spinner-border m-5" style="width: 3rem; height: 3rem;display:none" role="status" id="loader">
                                      </div>
                                    </button>


                        </div>
                    </div>
                    <br>
                    <div class="text-center ">
                        <span class="txt">
                            Don’t have an account?
                        </span>

                        <a  href="<?php echo e(route('register')); ?>" class="signuping">
                            Register Here
                        </a>
                    </div>
                </form>
            </div>
        </div>
        <script>
            document.getElementById("logbutton").addEventListener("click", function() {
            document.getElementById("loader").style.display="block";
            });
        </script>
    </div>
    <!-- Hero Section End -->
    <!-- end of banner -->
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/anatholek/Anathole/projects/Laravel/new-affl/resources/views/auth/login.blade.php ENDPATH**/ ?>