<?php echo e($slot); ?>

<?php /**PATH /home/anatholek/Anathole/projects/Laravel/new-affl/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>