<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/anatholek/Anathole/projects/Laravel/new-affl/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>