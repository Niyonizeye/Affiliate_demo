<?php return array (
  'abaut-component' => 'App\\Http\\Livewire\\AbautComponent',
  'contact-component' => 'App\\Http\\Livewire\\ContactComponent',
  'front-component' => 'App\\Http\\Livewire\\FrontComponent',
  'package-component' => 'App\\Http\\Livewire\\PackageComponent',
  'user.dashboard-component' => 'App\\Http\\Livewire\\User\\DashboardComponent',
  'user.user-dashboard-component' => 'App\\Http\\Livewire\\User\\UserDashboardComponent',
  'user.user-package-component' => 'App\\Http\\Livewire\\User\\UserPackageComponent',
);